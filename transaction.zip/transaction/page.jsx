"use client";

import { Suspense, useState, useEffect } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import {
  ClipboardClock,
  ScrollText,
  SlidersHorizontal,
  X,
} from "lucide-react";
import { Screen } from "@/components/affiliate/ui";
import { TransactionItem } from "@/components/affiliate/cards";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { useLocation } from "@/hooks/useLocation";
import { PendingCountdownTimer } from "@/components/PendingCountdownTimer";
import { EmptyState } from "@/components/EmptyState";
import BackToTopButton from "@/components/BackToTopButton";


const mapStatus = (statusNum) => {
  switch (statusNum) {
    case 6:
      return { label: "Pending", text: "Menunggu Pembayaran", color: "bg-amber-50 text-amber-700 border-amber-200" };
    case 0:
      return { label: "Pending", text: "Menunggu Konfirmasi", color: "bg-blue-50 text-blue-700 border-blue-200" };
    case 1:
      return { label: "Berhasil", text: "Dikonfirmasi", color: "bg-emerald-50 text-emerald-700 border-emerald-200" };
    case 3:
      return { label: "Berhasil", text: "Selesai", color: "bg-emerald-50 text-emerald-700 border-emerald-200" };
    default:
      return { label: "Dibatalkan", text: "Dibatalkan", color: "bg-rose-50 text-rose-700 border-rose-200" };
  }
};

export default function TransactionPage() {
  return (
    <Suspense fallback={null}>
      <TransactionPageInner />
    </Suspense>
  );
}

function TransactionPageInner() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  // Tab disimpan di URL (?tab=affiliate) supaya kembali dari halaman detail
  // tetap di tab yang sama.
  const [tab, setTabState] = useState(() => (searchParams.get("tab") === "affiliate" ? "affiliate" : "buyer"));
  const setTab = (next) => {
    setTabState(next);
    router.replace(next === "affiliate" ? `${pathname}?tab=affiliate` : pathname, { scroll: false });
  };
  const { lat, lng } = useLocation();

  const [affiliateItems, setAffiliateItems] = useState([]);
  const [buyerItems, setBuyerItems] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const [favoriteItems, setFavoriteItems] = useState([]);
  const [highCommissionItems, setHighCommissionItems] = useState([]);
  const [nearbyItems, setNearbyItems] = useState([]);
  const [isFavLoading, setIsFavLoading] = useState(false);
  const [isLoadingItems, setIsLoadingItems] = useState(false);

  const [categories, setCategories] = useState([]);

  const [statusFilter, setStatusFilter] = useState("Semua");
  const [sortOrder, setSortOrder] = useState("Terbaru");
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [datePeriod, setDatePeriod] = useState("Semua");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [tempStatus, setTempStatus] = useState("Semua");
  const [tempSort, setTempSort] = useState("Terbaru");
  const [tempCategories, setTempCategories] = useState([]);
  const [tempDatePeriod, setTempDatePeriod] = useState("Semua");
  const [tempStartDate, setTempStartDate] = useState("");
  const [tempEndDate, setTempEndDate] = useState("");


  useEffect(() => {
    fetch("/api/item-categories")
      .then((res) => res.json())
      .then((res) => {
        if (res.success && Array.isArray(res.data)) {
          setCategories(res.data);
        }
      })
      .catch((err) => console.error("Gagal load kategori:", err));
  }, []);

  useEffect(() => {
    setIsLoading(true);
    const apiEndpoint = tab === "affiliate" ? "/api/transaction" : "/api/buyer/transaction";

    fetch(apiEndpoint)
      .then((res) => res.json())
      .then((res) => {
        if (res.success && res.data?.order_items) {
          const mapped = res.data.order_items.map((item) => {
            const statusInfo = mapStatus(item.status);
            const formattedDate = new Date(item.created_at).toLocaleDateString("id-ID", {
              day: "2-digit",
              month: "short",
              year: "numeric",
              hour: "2-digit",
              minute: "2-digit",
            });

            return {
              rawId: item.id,
              orderId: item.order_number,
              tab: tab,
              statusNum: item.status,
              status: statusInfo.label,
              statusText: statusInfo.text,
              // Pesanan batal tidak menghasilkan komisi/cashback -> jangan ditampilkan.
              isCancelled: statusInfo.label === "Dibatalkan",
              productName: `${item.item_name || "Produk"}`,
              merchantName: item.merchant_name || item.item_type_name || "Layanan",
              buyerName: item.buyer_name || "Anda Sendiri",
              date: formattedDate,
              createdAt: new Date(item.created_at),
              createdAtRaw: item.created_at, // 🌟 simpan string mentah ISO
              price: Number(item.final_subtotal || item.subtotal),
              commission: Number(item.affiliate_commission || 0),
              // Checkout dari halaman sendiri (afiliator item = pemesan) -> komisi jadi cashback.
              // purchaser_id = orders.affiliator_id (order baru) atau orders.buyer_id (order lama).
              isOwnPurchase:
                item.affiliator_id != null &&
                (item.purchaser_id ?? item.buyer_id) != null &&
                String(item.affiliator_id) === String(item.purchaser_id ?? item.buyer_id),
              categoryId: item.category_id,
              payment_url: item.payment_url,
              categorySlug: item.category_slug,
              categoryName: item.category_name,
              desc: `${item.variant_name || " "}`,
              rawItem: item,
            };
          });

          if (tab === "affiliate") {
            setAffiliateItems(mapped);
          } else {
            setBuyerItems(mapped);
          }
        } else {
          if (tab === "affiliate") setAffiliateItems([]);
          else setBuyerItems([]);
        }
      })
      .catch((err) => console.error("Error fetching transactions:", err))
      .finally(() => setIsLoading(false));
  }, [tab]);

  useEffect(() => {
    async function fetchCatalogPreviews(lat = null, lng = null) {
      try {
        setIsLoadingItems(true);

        const params = new URLSearchParams({ limit: "6" });
        if (lat && lng) {
          params.append("lat", lat.toString());
          params.append("lng", lng.toString());
        }

        const [resFav, resHigh, resNear] = await Promise.all([
          fetch(`/api/items/favorite?${params.toString()}`).then((r) => r.json()),
          fetch(`/api/items/high-commission?${params.toString()}`).then((r) => r.json()),
          fetch(`/api/items?limit=20&sort=nearby&${params.toString()}`).then((r) => r.json()),
        ]);

        if (resFav?.success) setFavoriteItems(resFav.data || []);
        if (resHigh?.success) setHighCommissionItems(resHigh.data || []);
        if (resNear?.success) setNearbyItems(resNear.data || []);
      } catch (err) {
        console.error("Failed fetching catalog previews:", err);
      } finally {
        setIsLoadingItems(false);
      }
    }

    fetchCatalogPreviews(lat, lng);
  }, [lat, lng]);

  const handleToggleCategory = (slugOrId) => {
    if (slugOrId === "semua") {
      setTempCategories([]);
      return;
    }
    setTempCategories((prev) =>
      prev.includes(slugOrId)
        ? prev.filter((item) => item !== slugOrId)
        : [...prev, slugOrId]
    );
  };

  const handleOpenFilter = () => {
    setTempStatus(statusFilter);
    setTempSort(sortOrder);
    setTempCategories(selectedCategories);
    setTempDatePeriod(datePeriod);
    setTempStartDate(startDate);
    setTempEndDate(endDate);
    setIsFilterOpen(true);
  };

  const handleApplyFilter = () => {
    setStatusFilter(tempStatus);
    setSortOrder(tempSort);
    setSelectedCategories(tempCategories);
    setDatePeriod(tempDatePeriod);
    setStartDate(tempStartDate);
    setEndDate(tempEndDate);
    setIsFilterOpen(false);
  };

  const handleResetFilter = () => {
    setTempStatus("Semua");
    setTempSort("Terbaru");
    setTempCategories([]);
    setTempDatePeriod("Semua");
    setTempStartDate("");
    setTempEndDate("");
  };

  const handleItemClick = (item) => {
    if (!item.rawId) return;
    router.push(`/transaction/${item.tab}/${item.rawId}`);
  };

  const baseList = tab === "affiliate" ? affiliateItems : buyerItems;

  let list = baseList.filter((t) => {
    if (statusFilter !== "Semua" && t.status !== statusFilter) return false;

    if (selectedCategories.length > 0) {
      const matchSlug = selectedCategories.includes(t.categorySlug);
      const matchId = selectedCategories.includes(String(t.categoryId));
      const matchName = selectedCategories.some(
        (sc) => sc.toLowerCase() === t.categoryName?.toLowerCase()
      );
      if (!matchSlug && !matchId && !matchName) return false;
    }

    if (datePeriod !== "Semua") {
      const itemDate = t.createdAt;
      const now = new Date();

      if (datePeriod === "Hari Ini") {
        const isToday =
          itemDate.getDate() === now.getDate() &&
          itemDate.getMonth() === now.getMonth() &&
          itemDate.getFullYear() === now.getFullYear();
        if (!isToday) return false;
      } else if (datePeriod === "Minggu Ini") {
        const oneWeekAgo = new Date();
        oneWeekAgo.setDate(now.getDate() - 7);
        if (itemDate < oneWeekAgo) return false;
      } else if (datePeriod === "Bulan Ini") {
        const isThisMonth =
          itemDate.getMonth() === now.getMonth() &&
          itemDate.getFullYear() === now.getFullYear();
        if (!isThisMonth) return false;
      } else if (datePeriod === "Custom") {
        if (startDate) {
          const sDate = new Date(startDate);
          sDate.setHours(0, 0, 0, 0);
          if (itemDate < sDate) return false;
        }
        if (endDate) {
          const eDate = new Date(endDate);
          eDate.setHours(23, 59, 59, 999);
          if (itemDate > eDate) return false;
        }
      }
    }

    return true;
  });

  if (sortOrder === "Terlama") {
    list = [...list].sort((a, b) => a.createdAt - b.createdAt);
  } else if (sortOrder === "Terbaru") {
    list = [...list].sort((a, b) => b.createdAt - a.createdAt);
  } else if (sortOrder === "Komisi Terbesar") {
    list = [...list].sort((a, b) => (b.commission || 0) - (a.commission || 0));
  }

  const activeFiltersCount =
    (statusFilter !== "Semua" ? 1 : 0) +
    (sortOrder !== "Terbaru" ? 1 : 0) +
    (selectedCategories.length > 0 ? selectedCategories.length : 0) +
    (datePeriod !== "Semua" ? 1 : 0);

  return (
    <Screen className="fixed inset-0 bg-slate-50/50 pb-[130px] no-scrollbar [::-webkit-scrollbar]:hidden [-ms-overflow-style:none] scrollbar-none mx-auto -mt-6 overflow-y-auto md:w-[412px]">
     
      {/* HEADER TAB */}
      <div className="sticky top-0 z-40 bg-white px-4 pt-2 pb-0 -mx-4 -mt-4 mb-8 border-b border-slate-200 ">
        <div className="grid grid-cols-2 gap-0 border-b border-slate-100">
          <button
            type="button"
            onClick={() => { setTab("buyer"); setStatusFilter("Semua"); }}
            className={cn(
              "flex items-center justify-center gap-2 py-3 text-xs font-bold transition-all border-b-2 cursor-pointer",
              tab === "buyer"
                ? "border-primary text-primary"
                : "border-transparent text-slate-500 hover:text-slate-700"
            )}
          >
            <ScrollText className={cn("h-4 w-4", tab === "buyer" ? "text-primary" : "text-slate-400")} />
            Pesanan Kamu
          </button>
          <button
            type="button"
            onClick={() => { setTab("affiliate"); setStatusFilter("Semua"); }}
            className={cn(
              "flex items-center justify-center gap-2 py-3 text-xs font-bold transition-all border-b-2 cursor-pointer",
              tab === "affiliate"
                ? "border-primary text-primary"
                : "border-transparent text-slate-500 hover:text-slate-700"
            )}
          >
            <ClipboardClock className={cn("h-4 w-4", tab === "affiliate" ? "text-primary" : "text-slate-400")} />
            Afiliasi
          </button>
        </div>
      </div>

      {/* FILTER & TRANSAKSI INFO */}
      {!isLoading && baseList.length > 0 && (
        <div className="flex items-center justify-between gap-3 px-4 py-2.5 text-slate-700 text-xs font-semibold">
          <span className="text-[11px] font-bold text-slate-900">{list.length} Transaksi</span>

          <button
            type="button"
            onClick={handleOpenFilter}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 cursor-pointer"
          >
            <span><SlidersHorizontal  className="h-4 w-4"  /></span>
            <span>Filter</span>
            {activeFiltersCount > 0 && (
              <span className="ml-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[9px] font-bold text-white">
                {activeFiltersCount}
              </span>
            )}
          </button>
        </div>
      )}

      {/* CONTENT TRANSAKSI */}
      {isLoading ? (
        <div className="mt-2 space-y-3">
          {Array.from({ length: 4 }).map((_, idx) => (
            <div key={idx} className="p-3.5 rounded-sm bg-white border border-slate-200 shadow-2xs space-y-2.5">
              <div className="flex items-center justify-between">
                <Skeleton className="h-4 w-28 rounded-sm" />
                <Skeleton className="h-5 w-20 rounded-sm" />
              </div>
              <Skeleton className="h-4 w-3/4 rounded-sm" />
              <div className="flex items-center justify-between pt-1">
                <Skeleton className="h-3.5 w-24 rounded-sm" />
                <Skeleton className="h-4 w-28 rounded-sm" />
              </div>
            </div>
          ))}
        </div>
     ) : list.length === 0 ? (
  <EmptyState
    title={
      tab === "affiliate"
        ? "Belum Ada Riwayat Transaksi Afiliasi"
        : "Belum Ada Riwayat Pembelian"
    }
    description={
      tab === "affiliate"
        ? "Bagikan link produk ke pembeli untuk mulai menghasilkan komisi dari setiap transaksi."
        : "Kamu belum pernah melakukan pesanan. Temukan layanan terbaik dan mulai bertransaksi di Konksi."
    }
  />
) : (
        <div className="mt-2 space-y-3">
          {list.map((t, i) => (
            <div
              key={t.rawId || `${t.orderId}-${i}`}
              className="bg-white border border-slate-200 rounded-sm p-3.5 shadow-2xs hover:shadow-xs transition-all"
            >
              <div onClick={() => handleItemClick(t)} className="cursor-pointer">
                <TransactionItem item={t} index={i} variant={tab} />
              </div>

              {/* 🌟 TIMER MUNDUR BEBAS INFINITE LOOP (KHUSUS BUYER & STATUS PENDING) */}
              {tab === "buyer" && t.statusNum === 6 && (
                <PendingCountdownTimer createdAtString={t.createdAtRaw} paymentUrl={t.payment_url} />
              )}
            </div>
          ))}
        </div>
      )}

    
      {/* OFFCANVAS FILTER BOTTOM SHEET */}
      <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
        <SheetContent
          side="bottom"
          className="fixed inset-x-0 bottom-0 mx-auto w-full md:max-w-103 rounded-t-[1.5rem] max-h-[88vh] flex flex-col p-0 border-t border-slate-200 bg-white z-50 shadow-2xl"
        >
          {/* Handle Top Drag Bar */}
          <div className="w-12 h-1 bg-slate-300 rounded-full mx-auto my-2.5 shrink-0" />

          {/* Header Modal */}
          <SheetHeader className="flex flex-row items-center justify-between px-4 pr-12 border-b border-border shrink-0 pb-3">
            <SheetTitle className="text-base font-bold text-foreground">
              Urutkan & Filter
            </SheetTitle>

            <button
              type="button"
              onClick={handleResetFilter}
              className="text-xs font-bold text-primary cursor-pointer hover:underline"
            >
              Reset
            </button>
          </SheetHeader>

          {/* Body Modal (Scrollable Content) */}
          <div className="flex-1 overflow-y-auto p-5 space-y-6 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] scrollbar-none">

            {/* A. PILLS FILTER DIPILIH */}
            {(tempSort !== "Terbaru" || tempStatus !== "Semua" || tempCategories.length > 0 || tempDatePeriod !== "Semua") && (
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-900">Filter Dipilih</h4>
                <div className="flex flex-wrap gap-2">
                  {tempSort !== "Terbaru" && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-xs text-blue-700 font-medium">
                      Sort: {tempSort}
                      <X className="w-3.5 h-3.5 cursor-pointer" onClick={() => setTempSort("Terbaru")} />
                    </span>
                  )}
                  {tempStatus !== "Semua" && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-xs text-blue-700 font-medium">
                      Status: {tempStatus}
                      <X className="w-3.5 h-3.5 cursor-pointer" onClick={() => setTempStatus("Semua")} />
                    </span>
                  )}
                  {/* Mapping Multiple Categories Pills */}
                  {tempCategories.map((catSlug) => {
                    const catName = categories.find(
                      (c) => c.slug === catSlug || String(c.id) === String(catSlug)
                    )?.name || catSlug;
                    return (
                      <span
                        key={catSlug}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-xs text-blue-700 font-medium"
                      >
                        Cat: {catName}
                        <X
                          className="w-3.5 h-3.5 cursor-pointer"
                          onClick={() => handleToggleCategory(catSlug)}
                        />
                      </span>
                    );
                  })}
                  {tempDatePeriod !== "Semua" && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-xs text-blue-700 font-medium">
                      Waktu: {tempDatePeriod}
                      <X className="w-3.5 h-3.5 cursor-pointer" onClick={() => setTempDatePeriod("Semua")} />
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* B. URUTKAN / SORTIR */}
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Urutkan</h4>
              <div className="flex flex-wrap gap-2">
                {["Terbaru", "Terlama", ...(tab === "affiliate" ? ["Komisi Terbesar"] : [])].map((opt) => {
                  const isSelected = tempSort === opt;
                  return (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setTempSort(opt)}
                      className={`px-3.5 py-1.5 rounded-full text-xs font-medium border transition-all active:scale-95 cursor-pointer ${isSelected
                        ? "bg-blue-50 border-primary text-primary font-bold shadow-2xs"
                        : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                        }`}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* C. STATUS TRANSAKSI */}
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Status Transaksi</h4>
              <div className="flex flex-wrap gap-2">
                {["Semua", "Berhasil", "Pending", "Dibatalkan"].map((st) => {
                  const isSelected = tempStatus === st;
                  return (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setTempStatus(st)}
                      className={`px-3.5 py-1.5 rounded-full text-xs font-medium border transition-all active:scale-95 cursor-pointer ${isSelected
                        ? "bg-blue-50 border-primary text-primary font-bold shadow-2xs"
                        : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                        }`}
                    >
                      {st === "Semua" ? "Semua Status" : st}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* D. KATEGORI KATALOG (MULTIPLE CHOICE BUTTONS) */}
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                Kategori Katalog <span className="text-[10px] text-slate-400 font-normal lowercase">(bisa pilih lebih dari satu)</span>
              </h4>
              <div className="flex flex-wrap gap-2 max-h-36 overflow-y-auto no-scrollbar">
                <button
                  type="button"
                  onClick={() => handleToggleCategory("semua")}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-medium border transition-all active:scale-95 cursor-pointer ${tempCategories.length === 0
                    ? "bg-blue-50 border-primary text-primary font-bold shadow-2xs"
                    : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                    }`}
                >
                  Semua Kategori
                </button>
                {categories.map((c) => {
                  const slugOrId = c.slug || String(c.id);
                  const isSelected = tempCategories.includes(slugOrId);
                  return (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => handleToggleCategory(slugOrId)}
                      className={`px-3.5 py-1.5 rounded-full text-xs font-medium border transition-all active:scale-95 cursor-pointer ${isSelected
                        ? "bg-blue-50 border-primary text-primary font-bold shadow-2xs"
                        : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                        }`}
                    >
                      {c.name}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* E. TANGGAL PEMESANAN */}
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Tanggal Pemesanan</h4>
              <div className="flex flex-wrap gap-2">
                {["Semua", "Hari Ini", "Minggu Ini", "Bulan Ini", "Custom"].map((period) => {
                  const isSelected = tempDatePeriod === period;
                  return (
                    <button
                      key={period}
                      type="button"
                      onClick={() => setTempDatePeriod(period)}
                      className={`px-3.5 py-1.5 rounded-full text-xs font-medium border transition-all active:scale-95 cursor-pointer ${isSelected
                        ? "bg-blue-50 border-primary text-primary font-bold shadow-2xs"
                        : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                        }`}
                    >
                      {period === "Custom" ? "Tentukan Periode" : period}
                    </button>
                  );
                })}
              </div>

              {/* INPUT RANGE TANGGAL KHUSUS "TENTUKAN PERIODE" */}
              {tempDatePeriod === "Custom" && (
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="text-[10px] text-slate-500 font-medium mb-1 block">Dari Tanggal</label>
                    <Input
                      type="date"
                      value={tempStartDate}
                      onChange={(e) => setTempStartDate(e.target.value)}
                      className="h-9 text-xs bg-slate-50 border-slate-200 rounded-sm"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-500 font-medium mb-1 block">Sampai Tanggal</label>
                    <Input
                      type="date"
                      value={tempEndDate}
                      onChange={(e) => setTempEndDate(e.target.value)}
                      className="h-9 text-xs bg-slate-50 border-slate-200 rounded-sm"
                    />
                  </div>
                </div>
              )}
            </div>

          </div>

          {/* Footer Modal */}
          <div className="p-4 border-t border-slate-100 bg-white shrink-0">
            <Button
              type="button"
              onClick={handleApplyFilter}
              className="w-full h-11 bg-primary text-white font-bold rounded-sm shadow-md hover:bg-primary/90 transition-all cursor-pointer text-xs"
            >
              Terapkan
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      <BackToTopButton />
    </Screen>
  );
}