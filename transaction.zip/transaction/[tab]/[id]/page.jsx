"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import {
  CalendarCheck,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronLeft,
  Copy,
  CreditCard,
  ExternalLink,
  Hourglass,
  Link as LinkIcon,
  Mail,
  MapPin,
  Phone,
  ReceiptText,
  RotateCcw,
  Store,
  StickyNote,
  User,
  Wallet,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { rp } from "@/components/affiliate/ui";
import { encodeId } from "@/lib/hashids";
import { useUserStore } from "@/store/useUserStore";
import FollowUpCard from "@/components/transaction/detail/FollowUpCard";
import {
  PAYMENT_WINDOW_MS,
  TX_STEPS,
  distinctVariant,
  formatDateTime,
  formatPhoneDisplay,
  parseApiDate,
  scheduleParts,
  statusExplanation,
  txStatus,
} from "@/components/transaction/detail/txDetailFormat";

const TABS = { buyer: "/api/buyer/transaction", affiliate: "/api/transaction" };

const TONES = {
  amber: { icon: "bg-amber-100 text-amber-700", soft: "bg-amber-50 text-amber-800" },
  blue: { icon: "bg-blue-100 text-blue-700", soft: "bg-blue-50 text-blue-800" },
  emerald: { icon: "bg-emerald-100 text-emerald-700", soft: "bg-emerald-50 text-emerald-800" },
  rose: { icon: "bg-rose-100 text-rose-700", soft: "bg-rose-50 text-rose-800" },
};

const STATUS_ICONS = { 6: Wallet, 0: Hourglass, 1: CalendarCheck, 3: CheckCircle2 };

async function fetchDetail(tab, id) {
  const res = await fetch(`${TABS[tab]}?id=${encodeURIComponent(id)}`, { cache: "no-store" });
  const json = await res.json().catch(() => null);
  if (res.status === 404) return null;
  if (!res.ok || !json?.success) throw new Error(json?.message || "Detail transaksi belum bisa dimuat.");
  return json.data;
}

/** Sisa waktu bayar (ms) untuk status 6; null saat belum dihitung di client. */
function usePaymentCountdown(createdAt, active) {
  const [left, setLeft] = useState(null);
  useEffect(() => {
    if (!active) return undefined;
    const created = parseApiDate(createdAt);
    if (!created) return undefined;
    const expiry = created.getTime() + PAYMENT_WINDOW_MS;
    const tick = () => setLeft(Math.max(0, expiry - Date.now()));
    const first = setTimeout(tick, 0);
    const timer = setInterval(tick, 1000);
    return () => {
      clearTimeout(first);
      clearInterval(timer);
    };
  }, [createdAt, active]);
  return active ? left : null;
}

const mmss = (ms) => `${String(Math.floor(ms / 60000)).padStart(2, "0")}:${String(Math.floor((ms % 60000) / 1000)).padStart(2, "0")}`;

async function copyText(text, label) {
  try {
    await navigator.clipboard.writeText(text);
    toast.success(`${label} tersalin`);
  } catch {
    toast.error("Belum bisa menyalin");
  }
}

/* ------------------------------------------------------------------ */

function Card({ title, aside, children, className }) {
  return (
    <section className={cn("rounded-2xl border border-border bg-card p-4", className)}>
      {title && (
        <div className="mb-3 flex items-center justify-between gap-2">
          <h2 className="text-[13px] font-bold text-foreground">{title}</h2>
          {aside}
        </div>
      )}
      {children}
    </section>
  );
}

function InfoRow({ icon: Icon, label, children, action }) {
  return (
    <div className="flex items-start gap-3 py-2">
      <Icon className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
      <div className="min-w-0 flex-1">
        <p className="text-[11px] text-muted-foreground">{label}</p>
        <div className="mt-0.5 text-[13px] font-medium text-foreground wrap-break-word">{children}</div>
      </div>
      {action}
    </div>
  );
}

function CopyButton({ value, label }) {
  if (!value) return null;
  return (
    <button
      type="button"
      onClick={() => copyText(String(value), label)}
      aria-label={`Salin ${label.toLowerCase()}`}
      className="grid size-8 shrink-0 cursor-pointer place-items-center rounded-full text-muted-foreground active:bg-muted"
    >
      <Copy className="size-3.5" />
    </button>
  );
}

function Stepper({ step }) {
  return (
    <ol className="mt-5 grid grid-cols-4">
      {TX_STEPS.map((label, i) => {
        const done = i < step || (i === step && step === TX_STEPS.length - 1);
        const current = i === step && !done;
        return (
          <li key={label} className="relative flex flex-col items-center text-center">
            {i > 0 && (
              <span
                aria-hidden
                className={cn("absolute right-1/2 top-2.5 h-0.5 w-full -translate-y-1/2", i <= step ? "bg-primary" : "bg-border")}
              />
            )}
            <span
              className={cn(
                "relative z-10 grid size-5 place-items-center rounded-full border-2",
                done ? "border-primary bg-primary text-primary-foreground" : current ? "border-primary bg-card" : "border-border bg-card"
              )}
            >
              {done ? <Check className="size-3" strokeWidth={3} /> : current ? <span className="size-2 rounded-full bg-primary" /> : null}
            </span>
            <span className={cn("mt-1.5 text-[10.5px]", i <= step ? "font-semibold text-foreground" : "text-muted-foreground")}>
              {label}
            </span>
          </li>
        );
      })}
    </ol>
  );
}

function DetailSkeleton() {
  return (
    <div className="space-y-3 px-4 pt-4" aria-busy="true" aria-label="Memuat detail transaksi">
      <div className="h-44 animate-pulse rounded-2xl bg-muted" />
      <div className="h-28 animate-pulse rounded-2xl bg-muted" />
      <div className="h-24 animate-pulse rounded-2xl bg-muted" />
      <div className="h-48 animate-pulse rounded-2xl bg-muted" />
    </div>
  );
}

/* ------------------------------------------------------------------ */

export default function TransactionDetailPage() {
  const params = useParams();
  const router = useRouter();
  const tab = TABS[params?.tab] ? params.tab : null;
  const id = params?.id;
  const isAffiliate = tab === "affiliate";

  const user = useUserStore((s) => s.user);
  const fetchUser = useUserStore((s) => s.fetchUser);

  const requestKey = `${tab}/${id}`;
  const [state, setState] = useState({ key: null, data: null, error: null });
  const [reloadToken, setReloadToken] = useState(0);
  const loading = tab && state.key !== `${requestKey}#${reloadToken}`;

  useEffect(() => {
    if (!user) fetchUser?.();
  }, [user, fetchUser]);

  useEffect(() => {
    if (!tab || !id) return undefined;
    let cancelled = false;
    const key = `${requestKey}#${reloadToken}`;
    fetchDetail(tab, id)
      .then((data) => !cancelled && setState({ key, data, error: null }))
      .catch((err) => !cancelled && setState({ key, data: null, error: err.message }));
    return () => {
      cancelled = true;
    };
  }, [tab, id, requestKey, reloadToken]);

  const d = state.data?.detail;
  const logs = useMemo(() => [...(state.data?.timeline_logs || [])].reverse(), [state.data]);
  const status = d ? txStatus(d.status) : null;
  const schedule = d ? scheduleParts(d.start_at_local || d.start_at, d.end_at_local || d.end_at) : null;
  const variant = distinctVariant(d);
  const left = usePaymentCountdown(d?.created_at, Number(d?.status) === 6);
  const expired = left === 0;

  const commission = Number(d?.affiliate_commission || 0);
  const isOwnPurchase = Boolean(d?.is_own_purchase);
  const showEarning = d && !status.cancelled && commission > 0 && (isAffiliate || isOwnPurchase);
  const productHref = d?.item_id && user?.username ? `/${user.username}/${encodeId(d.item_id)}` : null;

  const goBack = () => {
    if (window.history.length > 1) router.back();
    else router.push(`/transaction${isAffiliate ? "?tab=affiliate" : ""}`);
  };

  const shareProduct = () => {
    if (!productHref) return;
    copyText(`${window.location.origin}${productHref}`, "Link produk");
  };

  const StatusIcon = d ? STATUS_ICONS[Number(d.status)] || XCircle : null;
  const tone = status ? TONES[status.tone] : null;

  return (
    <div className="flex min-h-full w-full flex-1 flex-col bg-muted/40">
      {/* Header (fixed: sticky tidak berfungsi di dalam <main> overflow-x-hidden root layout) */}
      <div className="fixed left-1/2 top-0 z-40 w-full -translate-x-1/2 md:max-w-103">
        <header className="grid h-15 grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-2 border-b border-border bg-background/95 px-4 backdrop-blur">
          <button
            type="button"
            onClick={goBack}
            aria-label="Kembali"
            className="inline-flex size-9 cursor-pointer items-center justify-center rounded-full border border-border bg-card text-muted-foreground active:bg-accent"
          >
            <ChevronLeft className="size-4" />
          </button>
          <div className="min-w-0">
            <h1 className="truncate text-[15px] font-semibold tracking-tight">Detail Transaksi</h1>
            <p className="truncate text-[11px] text-muted-foreground">{isAffiliate ? "Penjualan afiliasi" : "Pesanan kamu"}</p>
          </div>
          <span className="size-9" aria-hidden />
        </header>
      </div>
      <div className="h-15 shrink-0" aria-hidden />

      {!tab ? (
        <EmptyNotice title="Halaman tidak ditemukan" onBack={() => router.push("/transaction")} />
      ) : loading ? (
        <DetailSkeleton />
      ) : state.error ? (
        <EmptyNotice
          title="Detail belum bisa dimuat"
          description={state.error}
          actionLabel="Coba lagi"
          onAction={() => setReloadToken((t) => t + 1)}
        />
      ) : !d ? (
        <EmptyNotice
          title="Transaksi tidak ditemukan"
          description="Transaksi ini tidak ada atau bukan milik akunmu."
          onBack={() => router.push(`/transaction${isAffiliate ? "?tab=affiliate" : ""}`)}
        />
      ) : (
        <main className="space-y-3 px-4 pb-32 pt-4">
          {/* ============ STATUS ============ */}
          <section className="rounded-2xl border border-border bg-card p-4">
            <div className="flex items-start gap-3">
              <span className={cn("grid size-11 shrink-0 place-items-center rounded-2xl", tone.icon)}>
                <StatusIcon className="size-5" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-[18px] font-bold leading-tight tracking-tight text-foreground">
                  {Number(d.status) === 6 && expired ? "Waktu Pembayaran Habis" : status.title}
                </p>
                <p className="mt-1 text-[12.5px] leading-relaxed text-muted-foreground">
                  {statusExplanation(d.status, tab, { hasSchedule: Boolean(schedule) })}
                </p>
              </div>
            </div>

            {Number(d.status) === 6 && left !== null && (
              <div className={cn("mt-4 flex items-center justify-between gap-3 rounded-xl px-3 py-2.5", expired ? TONES.rose.soft : tone.soft)}>
                <div>
                  <p className="text-[11px] font-medium opacity-80">{expired ? "Pesanan akan dibatalkan otomatis" : "Batal otomatis dalam"}</p>
                  {!expired && <p className="text-[20px] font-bold leading-tight tabular-nums">{mmss(left)}</p>}
                </div>
                {!isAffiliate && d.payment_url && !expired && (
                  <a
                    href={d.payment_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex h-10 shrink-0 items-center gap-1.5 rounded-full bg-primary px-4 text-[12.5px] font-bold text-primary-foreground active:scale-95"
                  >
                    Bayar sekarang <ExternalLink className="size-3.5" />
                  </a>
                )}
              </div>
            )}

            {status.cancelled ? (
              <p className={cn("mt-4 rounded-xl px-3 py-2.5 text-[12px] font-medium", TONES.rose.soft)}>
                Alur pesanan berhenti. Detail kejadian ada di riwayat pesanan di bawah.
              </p>
            ) : (
              <Stepper step={status.step} />
            )}
          </section>

          {/* ============ KOMISI / CASHBACK ============ */}
          {showEarning && (
            <section className="rounded-2xl bg-[#16122b] p-4 text-white">
              <p className="text-[11.5px] font-medium text-white/65">
                {isAffiliate ? "Komisi kamu dari pesanan ini" : "Cashback kamu"}
              </p>
              <p className="mt-1 text-[26px] font-bold leading-none tracking-tight tabular-nums">{rp(commission)}</p>
              <div className="mt-3 flex items-center justify-between gap-3 border-t border-white/10 pt-3 text-[11.5px]">
                <span className="text-white/70">
                  {Number(d.status) === 6 ? "Masuk ke saldo setelah pembeli membayar" : "Dikreditkan ke saldo saat pembayaran berhasil"}
                </span>
                <Link href="/balance" className="shrink-0 font-semibold text-amber-300">
                  Lihat saldo
                </Link>
              </div>
            </section>
          )}

          {/* ============ FOLLOW UP (khusus afiliasi) ============ */}
          {isAffiliate && <FollowUpCard detail={d} senderName={user?.name} expired={expired} />}

          {/* ============ PRODUK ============ */}
          <Card title="Produk">
            <div className="flex gap-3">
              <div className="size-16 shrink-0 overflow-hidden rounded-xl bg-muted">
                {d.image_url ? (
                  // eslint-disable-next-line @next/next/no-img-element -- URL CDN
                  <img src={d.image_url} alt="" className="size-full object-cover" />
                ) : (
                  <div className="grid size-full place-items-center text-muted-foreground">
                    <Store className="size-5" />
                  </div>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className="line-clamp-2 text-[13.5px] font-semibold leading-snug text-foreground">{d.item_name}</p>
                {variant && <p className="mt-0.5 truncate text-[12px] text-muted-foreground">{variant}</p>}
                <p className="mt-1 flex items-center gap-1 truncate text-[11.5px] text-muted-foreground">
                  <Store className="size-3 shrink-0" /> {d.merchant_name || "Mitra Konksi"}
                </p>
              </div>
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-1.5">
              {d.item_type_name && (
                <span className="rounded-full bg-muted px-2.5 py-1 text-[11px] font-medium text-muted-foreground">{d.item_type_name}</span>
              )}
              <span className="rounded-full bg-muted px-2.5 py-1 text-[11px] font-medium text-muted-foreground">
                {d.is_home_service ? "Home service" : "Di lokasi mitra"}
              </span>
              <span className="ml-auto text-[12px] text-muted-foreground tabular-nums">
                {d.quantity || 1} × {rp(Number(d.price || d.subtotal || 0))}
              </span>
            </div>
            {productHref && (
              isAffiliate ? (
                <button
                  type="button"
                  onClick={shareProduct}
                  className="mt-3 flex h-10 w-full cursor-pointer items-center justify-center gap-1.5 rounded-full border border-border text-[12.5px] font-semibold text-foreground active:bg-muted"
                >
                  <LinkIcon className="size-3.5" /> Salin link produk untuk dibagikan lagi
                </button>
              ) : (
                Number(d.status) === 3 && (
                  <Link
                    href={productHref}
                    className="mt-3 flex h-10 w-full items-center justify-center gap-1.5 rounded-full bg-primary text-[12.5px] font-bold text-primary-foreground active:scale-[0.99]"
                  >
                    <RotateCcw className="size-3.5" /> Pesan lagi
                  </Link>
                )
              )
            )}
          </Card>

          {/* ============ JADWAL ============ */}
          {schedule && (
            <Card
              title="Jadwal layanan"
              aside={
                <span
                  className={cn(
                    "rounded-full px-2.5 py-1 text-[11px] font-semibold",
                    schedule.upcoming && !status.cancelled ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
                  )}
                >
                  {status.cancelled ? "Tidak berlaku" : schedule.relative}
                </span>
              }
            >
              <div className="flex items-center gap-3.5">
                <div className="flex w-14 shrink-0 flex-col items-center overflow-hidden rounded-xl border border-border">
                  <span className="w-full bg-primary py-0.5 text-center text-[10px] font-bold uppercase text-primary-foreground">
                    {schedule.monthShort}
                  </span>
                  <span className="py-1 text-[22px] font-bold leading-none text-foreground">{schedule.dayNumber}</span>
                </div>
                <div className="min-w-0">
                  <p className="text-[13.5px] font-semibold capitalize text-foreground">{schedule.fullDate}</p>
                  <p className="mt-0.5 flex items-center gap-1 text-[12px] text-muted-foreground tabular-nums">
                    <CalendarDays className="size-3.5" /> {schedule.timeRange}
                  </p>
                </div>
              </div>
              {d.is_home_service && d.buyer_address && (
                <div className="mt-3 flex items-start gap-2 rounded-xl bg-muted/60 px-3 py-2.5 text-[12px] text-foreground">
                  <MapPin className="mt-0.5 size-3.5 shrink-0 text-primary" />
                  <span className="leading-relaxed">{d.buyer_address}</span>
                </div>
              )}
            </Card>
          )}

          {/* ============ PEMBAYARAN ============ */}
          <Card
            title="Rincian pembayaran"
            aside={
              d.payment_method && (
                <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2.5 py-1 text-[11px] font-semibold text-muted-foreground">
                  <CreditCard className="size-3" /> {d.payment_method}
                </span>
              )
            }
          >
            <dl className="space-y-2 text-[12.5px]">
              <div className="flex justify-between gap-3">
                <dt className="text-muted-foreground">Subtotal produk</dt>
                <dd className="font-medium tabular-nums">{rp(Number(d.subtotal || 0))}</dd>
              </div>
              {Number(d.home_service_fee || 0) > 0 && (
                <div className="flex justify-between gap-3">
                  <dt className="text-muted-foreground">Biaya home service</dt>
                  <dd className="font-medium tabular-nums">+{rp(Number(d.home_service_fee))}</dd>
                </div>
              )}
              {Number(d.discount_allocated || 0) > 0 && (
                <div className="flex justify-between gap-3">
                  <dt className="text-muted-foreground">Diskon pelanggan</dt>
                  <dd className="font-medium text-emerald-600 tabular-nums">-{rp(Number(d.discount_allocated))}</dd>
                </div>
              )}
              {Number(d.affiliator_discount || 0) > 0 && (
                <div className="flex justify-between gap-3">
                  <dt className="text-muted-foreground">Diskon afiliator</dt>
                  <dd className="font-medium text-emerald-600 tabular-nums">-{rp(Number(d.affiliator_discount))}</dd>
                </div>
              )}
              <div className="flex items-baseline justify-between gap-3 border-t border-dashed border-border pt-3">
                <dt className="font-semibold text-foreground">Total</dt>
                <dd className="text-[17px] font-bold text-foreground tabular-nums">{rp(Number(d.final_subtotal || 0))}</dd>
              </div>
            </dl>
            {/* Biaya penanganan dipotong dari pendapatan mitra (callback), bukan dari pembeli/komisi. */}
            {isAffiliate && Number(d.transaction_fee_amount || 0) > 0 && (
              <p className="mt-3 rounded-xl bg-muted/60 px-3 py-2 text-[11.5px] leading-relaxed text-muted-foreground">
                Biaya penanganan {rp(Number(d.transaction_fee_amount))} ditanggung mitra dan tidak mengurangi komisimu.
              </p>
            )}
          </Card>

          {/* ============ PEMBELI ============ */}
          <Card title={isAffiliate ? "Data pembeli" : "Data pemesan"}>
            <div className="divide-y divide-border">
              <InfoRow icon={User} label="Nama">{d.buyer_name || "-"}</InfoRow>
              <InfoRow icon={Phone} label="Nomor HP" action={<CopyButton value={d.buyer_phone} label="Nomor" />}>
                <span className="tabular-nums">{d.buyer_phone ? formatPhoneDisplay(d.buyer_phone) : "-"}</span>
              </InfoRow>
              <InfoRow icon={Mail} label="Email">{d.buyer_email || "-"}</InfoRow>
              {d.buyer_notes && (
                <InfoRow icon={StickyNote} label="Catatan untuk mitra">
                  <span className="font-normal leading-relaxed">{d.buyer_notes}</span>
                </InfoRow>
              )}
            </div>
          </Card>

          {/* ============ RIWAYAT ============ */}
          {logs.length > 0 && (
            <Card title="Riwayat pesanan" aside={<span className="text-[11px] text-muted-foreground">{logs.length} aktivitas</span>}>
              <ol className="relative">
                {logs.map((log, i) => (
                  <li key={log.id} className="relative flex gap-3 pb-4 last:pb-0">
                    {i < logs.length - 1 && <span aria-hidden className="absolute left-1.25 top-3 h-full w-px bg-border" />}
                    <span
                      className={cn(
                        "relative mt-1 size-2.75 shrink-0 rounded-full border-2",
                        i === 0 ? "border-primary bg-primary" : "border-border bg-card"
                      )}
                    />
                    <div className="min-w-0 flex-1">
                      <p className={cn("text-[12.5px] font-semibold", i === 0 ? "text-foreground" : "text-muted-foreground")}>{log.title}</p>
                      {log.description && <p className="mt-0.5 text-[12px] leading-relaxed text-muted-foreground">{log.description}</p>}
                      <p className="mt-1 text-[11px] text-muted-foreground/80 tabular-nums">{formatDateTime(log.created_at)}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </Card>
          )}

          {/* ============ INFO PESANAN ============ */}
          <Card title="Info pesanan">
            <div className="divide-y divide-border">
              <InfoRow icon={ReceiptText} label="Nomor pesanan" action={<CopyButton value={d.order_number} label="Nomor pesanan" />}>
                <span className="font-mono text-[12.5px]">{d.order_number}</span>
              </InfoRow>
              {d.invoice_number && (
                <InfoRow icon={ReceiptText} label="Nomor invoice" action={<CopyButton value={d.invoice_number} label="Nomor invoice" />}>
                  <span className="font-mono text-[12.5px]">{d.invoice_number}</span>
                </InfoRow>
              )}
              <InfoRow icon={CalendarDays} label="Waktu pesan">{formatDateTime(d.created_at)}</InfoRow>
            </div>
          </Card>
        </main>
      )}
    </div>
  );
}

function EmptyNotice({ title, description, actionLabel, onAction, onBack }) {
  return (
    <div className="flex flex-col items-center px-8 py-20 text-center">
      <div className="grid size-12 place-items-center rounded-full bg-muted text-muted-foreground">
        <ReceiptText className="size-5" />
      </div>
      <p className="mt-3 text-[14px] font-semibold text-foreground">{title}</p>
      {description && <p className="mt-1 text-[12px] text-muted-foreground">{description}</p>}
      {(onAction || onBack) && (
        <button
          type="button"
          onClick={onAction || onBack}
          className="mt-4 cursor-pointer rounded-full bg-primary px-4 py-2 text-[12px] font-semibold text-primary-foreground"
        >
          {actionLabel || "Kembali ke transaksi"}
        </button>
      )}
    </div>
  );
}
